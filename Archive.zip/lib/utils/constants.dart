class Constants {
  static const Duration requestsTimeout = Duration(seconds: 30);
}
