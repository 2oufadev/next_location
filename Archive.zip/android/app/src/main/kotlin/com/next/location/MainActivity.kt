package com.next.location

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
